ALTER TABLE `income_entries` ADD `receivedFrom` varchar(255);--> statement-breakpoint
ALTER TABLE `ticket_entries` ADD `source` varchar(255);